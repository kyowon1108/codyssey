def hello():
    return "Hello"

print(hello())